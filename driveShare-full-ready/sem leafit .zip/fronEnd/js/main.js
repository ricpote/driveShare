const API_BASE_URL = "http://localhost:5000/api";
const TOKEN_KEY = "uniride_token";
const USER_KEY = "uniride_current_user";
const allowedDomains = ["campus.fct.unl.pt", "fct.unl.pt"];

function showMessage(elementId, text, type) {
  const box = document.getElementById(elementId);
  if (!box) return;
  box.textContent = text;
  box.className = `message ${type}`;
}

function hideMessage(elementId) {
  const box = document.getElementById(elementId);
  if (!box) return;
  box.textContent = "";
  box.className = "message hidden";
}

function isUniversityEmail(email) {
  const domain = email.split("@")[1]?.toLowerCase();
  return allowedDomains.includes(domain);
}

function saveToken(token) { localStorage.setItem(TOKEN_KEY, token); }
function getToken() { return localStorage.getItem(TOKEN_KEY); }
function saveCurrentUser(user) { localStorage.setItem(USER_KEY, JSON.stringify(user)); }
function getCurrentUser() { return JSON.parse(localStorage.getItem(USER_KEY) || "null"); }
function clearSession() { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); }

async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers });
  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();

  if (!response.ok) {
    const errorMessage = typeof data === "object" && data?.error ? data.error : "Ocorreu um erro no servidor.";
    throw new Error(errorMessage);
  }
  return data;
}

function captureTokenFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const token = params.get("token");
  if (token) {
    saveToken(token);
    window.history.replaceState({}, document.title, window.location.pathname);
  }
}

const tabs = document.querySelectorAll(".tab");
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const googleLoginBtn = document.getElementById("googleLoginBtn");

if (tabs.length) {
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((item) => item.classList.remove("active"));
      tab.classList.add("active");
      const selected = tab.dataset.tab;
      loginForm.classList.toggle("active", selected === "login");
      registerForm.classList.toggle("active", selected === "register");
      hideMessage("message");
    });
  });
}

if (googleLoginBtn) {
  googleLoginBtn.addEventListener("click", () => {
    window.location.href = `${API_BASE_URL}/users/auth/google`;
  });
}

if (registerForm) {
  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    hideMessage("message");

    const name = document.getElementById("registerName").value.trim();
    const email = document.getElementById("registerEmail").value.trim().toLowerCase();
    const password = document.getElementById("registerPassword").value.trim();
    const confirmPassword = document.getElementById("registerConfirmPassword").value.trim();

    if (!isUniversityEmail(email)) return showMessage("message", "Usa um email universitário válido da FCT.", "error");
    if (password.length < 6) return showMessage("message", "A palavra-passe deve ter pelo menos 6 caracteres.", "error");
    if (password !== confirmPassword) return showMessage("message", "As palavras-passe não coincidem.", "error");

    try {
      await apiFetch("/users/register", { method: "POST", body: JSON.stringify({ name, email, password, phone: "" }) });
      const loginResult = await apiFetch("/users/login", { method: "POST", body: JSON.stringify({ email, password }) });
      saveToken(loginResult.token);
      saveCurrentUser({ name, email });
      showMessage("message", "Conta criada com sucesso.", "success");
      setTimeout(() => { window.location.href = "dashboard.html"; }, 700);
    } catch (error) {
      showMessage("message", error.message, "error");
    }
  });
}

if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    hideMessage("message");

    const email = document.getElementById("loginEmail").value.trim().toLowerCase();
    const password = document.getElementById("loginPassword").value.trim();

    try {
      const result = await apiFetch("/users/login", { method: "POST", body: JSON.stringify({ email, password }) });
      saveToken(result.token);
      saveCurrentUser({ email, name: email.split("@")[0] });
      showMessage("message", "Login efetuado com sucesso.", "success");
      setTimeout(() => { window.location.href = "dashboard.html"; }, 700);
    } catch (error) {
      showMessage("message", error.message, "error");
    }
  });
}

const rideForm = document.getElementById("rideForm");
if (rideForm) {
  captureTokenFromUrl();
  const currentUser = getCurrentUser();
  const token = getToken();
  if (!token) {
    window.location.href = "index.html";
  } else {
    const welcomeText = document.getElementById("welcomeText");
    if (welcomeText) welcomeText.textContent = `Olá, ${currentUser?.name || currentUser?.email || "utilizador"}.`;
    updateDashboardStats();
  }

  rideForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    hideMessage("rideMessage");

    const from = document.getElementById("origin").value.trim();
    const to = document.getElementById("destination").value.trim();
    const day = document.getElementById("rideDate").value;
    const time = document.getElementById("time").value;
    const totalSeats = Number(document.getElementById("seats").value);

    if (!day || !time) return showMessage("rideMessage", "Escolhe data e hora da boleia.", "error");

    try {
      const date = new Date(`${day}T${time}:00`);
      await apiFetch("/rides", { method: "POST", body: JSON.stringify({ from, to, date, totalSeats }) });
      showMessage("rideMessage", "Boleia guardada com sucesso.", "success");
      rideForm.reset();
      updateDashboardStats();
    } catch (error) {
      showMessage("rideMessage", error.message, "error");
    }
  });
}

async function updateDashboardStats() {
  const ridesEl = document.getElementById("totalRides");
  const seatsEl = document.getElementById("totalSeats");
  const co2El = document.getElementById("co2Saved");
  if (!ridesEl && !seatsEl && !co2El) return;
  try {
    const rides = await apiFetch("/rides", { method: "GET" });
    const totalRides = rides.length;
    const totalSeats = rides.reduce((sum, ride) => sum + Number(ride.availableSeats || 0), 0);
    const estimatedCo2 = (totalRides * 2.4).toFixed(1);
    if (ridesEl) ridesEl.textContent = totalRides;
    if (seatsEl) seatsEl.textContent = totalSeats;
    if (co2El) co2El.textContent = `${estimatedCo2} kg`;
  } catch (_) {
    if (ridesEl) ridesEl.textContent = "0";
    if (seatsEl) seatsEl.textContent = "0";
    if (co2El) co2El.textContent = "0 kg";
  }
}

const logoutBtn = document.getElementById("logoutBtn");
if (logoutBtn) logoutBtn.addEventListener("click", () => { clearSession(); window.location.href = "index.html"; });

captureTokenFromUrl();
