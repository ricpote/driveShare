const API_BASE_URL = "http://localhost:5000/api";
const TOKEN_KEY = "uniride_token";
const container = document.getElementById("ridesContainer");

function getToken() { return localStorage.getItem(TOKEN_KEY); }

async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers });
  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();

  if (!response.ok) {
    const errorMessage = typeof data === "object" && data?.error ? data.error : "Não foi possível concluir o pedido.";
    throw new Error(errorMessage);
  }
  return data;
}

function formatRideDate(dateValue) {
  const date = new Date(dateValue);
  return new Intl.DateTimeFormat("pt-PT", { dateStyle: "short", timeStyle: "short" }).format(date);
}

async function loadRides() {
  const token = getToken();
  if (!token) {
    window.location.href = "index.html";
    return;
  }

  try {
    const rides = await apiFetch("/rides", { method: "GET" });
    if (!rides.length) {
      container.innerHTML = '<div class="empty-state">Ainda não existem boleias criadas.</div>';
      return;
    }

    container.innerHTML = "";
    rides.sort((a, b) => new Date(a.date) - new Date(b.date)).forEach((ride) => {
      const card = document.createElement("article");
      card.className = "ride-card";
      card.innerHTML = `
        <h3>${ride.from} → ${ride.to}</h3>
        <div class="ride-meta">Partida: ${formatRideDate(ride.date)}</div>
        <p>Lugares disponíveis: <strong>${ride.availableSeats}</strong> / ${ride.totalSeats}</p>
        <button class="inline-btn" data-ride-id="${ride._id}">Pedir boleia</button>
      `;
      container.appendChild(card);
    });
  } catch (error) {
    container.innerHTML = `<div class="empty-state">${error.message}</div>`;
  }
}

container?.addEventListener("click", async (event) => {
  if (!event.target.matches(".inline-btn")) return;
  const rideId = event.target.dataset.rideId;
  try {
    await apiFetch(`/rides/${rideId}/request`, { method: "POST", body: JSON.stringify({ lat: null, lng: null }) });
    alert("Pedido enviado ao condutor com sucesso.");
  } catch (error) {
    alert(error.message);
  }
});

loadRides();
